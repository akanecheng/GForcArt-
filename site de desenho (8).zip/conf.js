const menu = document.getElementById("menuLateral");


function toggleMenu (){
    menu.classList.toggle("aberto");
  }
